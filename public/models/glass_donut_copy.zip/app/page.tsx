import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/7GkFf3zmHys5cop5/scene.splinecode" 
      />
    </main>
  );
}
